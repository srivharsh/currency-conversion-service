CREATE TABLE exchange_value
(
id int,
currency_from varchar(100),
currency_to varchar(100),
conversion_multiple BIGINT,
port int
);